using System;
using Platformer.Mechanics;
using UnityEngine;

namespace Platformer.Model
{
    /// <summary>
    /// Modelo principal del juego. Contiene los datos compartidos por la
    /// simulación (jugador, cámara y punto de reaparición) y el estado de
    /// progreso de la partida: elementos obtenidos, ataques desbloqueados,
    /// monedas recogidas y gancho.
    /// Es la única fuente de verdad del estado de la partida.
    /// </summary>
    [System.Serializable]
    public class PlatformerModel
    {
        /// <summary>
        /// The virtual camera in the scene.
        /// </summary>
        public Unity.Cinemachine.CinemachineCamera virtualCamera;

        /// <summary>
        /// The main component which controls the player sprite, controlled
        /// by the user.
        /// </summary>
        public PlayerController player;

        /// <summary>
        /// The spawn point in the scene.
        /// </summary>
        public Transform spawnPoint;

        /// <summary>
        /// A global jump modifier applied to all initial jump velocities.
        /// </summary>
        public float jumpModifier = 1.5f;

        /// <summary>
        /// A global jump modifier applied to slow down an active jump when
        /// the user releases the jump input.
        /// </summary>
        public float jumpDeceleration = 0.5f;

        [Header("Personajes")]
        [SerializeField] private GameElement[] knightElements = { GameElement.Fuego, GameElement.Rayo };
        [SerializeField] private GameElement[] cyberElements = { GameElement.Hielo, GameElement.Viento };

        [System.NonSerialized] private int currentCharacter;
        [System.NonSerialized] private int elementsMask;
        [System.NonSerialized] private int attacksMask;
        [System.NonSerialized] private int tokenCount;
        [System.NonSerialized] private GameElement activeElement;
        [System.NonSerialized] private bool grappleUnlocked;
        [System.NonSerialized] private string message = string.Empty;
        [System.NonSerialized] private float messageExpiry;

        /// <summary>
        /// Número de monedas (tokens) recogidas por el jugador.
        /// </summary>
        public int TokenCount => tokenCount;

        /// <summary>
        /// Índice del personaje actualmente seleccionado.
        /// </summary>
        public int CurrentCharacterIndex => currentCharacter;

        /// <summary>
        /// Nombre legible del personaje actual.
        /// </summary>
        public string CurrentCharacterName => currentCharacter == 0 ? "CABALLERO" : "CYBER 10";

        /// <summary>
        /// Cantidad de personajes seleccionables.
        /// </summary>
        public int CharacterCount => 2;

        /// <summary>
        /// Elemento que el jugador tiene equipado en este momento.
        /// </summary>
        public GameElement ActiveElement => activeElement;

        /// <summary>
        /// Devuelve los dos elementos asignados a un personaje.
        /// </summary>
        public GameElement[] ElementsForCharacter(int index)
        {
            return index == 0 ? knightElements : cyberElements;
        }

        /// <summary>
        /// Elementos del personaje activo.
        /// </summary>
        public GameElement[] CurrentElements => ElementsForCharacter(currentCharacter);

        /// <summary>
        /// True cuando el jugador ya abrió el cofre del gancho.
        /// </summary>
        public bool GrappleUnlocked => grappleUnlocked;

        /// <summary>
        /// True si el jugador obtuvo el elemento indicado.
        /// </summary>
        public bool HasElement(GameElement element)
        {
            if (element == GameElement.Ninguno) return false;
            return (elementsMask & Bit(element)) != 0;
        }

        /// <summary>
        /// True si el jugador desbloqueó el ataque del elemento indicado.
        /// </summary>
        public bool HasAttack(GameElement element)
        {
            if (element == GameElement.Ninguno) return false;
            return (attacksMask & Bit(element)) != 0;
        }

        /// <summary>
        /// True cuando el jugador posee los dos elementos y puede alternar
        /// entre ellos con la tecla de cambio.
        /// </summary>
        public bool CanSwitchElement => CurrentElements != null && CurrentElements.Length >= 2;

        /// <summary>
        /// Mensaje informativo que muestra el HUD. Se vacía solo cuando pasa
        /// el tiempo de duración.
        /// </summary>
        public string Message => Time.time < messageExpiry ? message : string.Empty;

        /// <summary>
        /// Registra un elemento obtenido en un cofre. El elemento recién
        /// conseguido queda equipado para que su ataque se pueda usar
        /// inmediatamente.
        /// </summary>
        public void CollectElement(GameElement element)
        {
            if (element == GameElement.Ninguno) return;
            elementsMask |= Bit(element);
            activeElement = element;
        }

        /// <summary>
        /// Registra el ataque desbloqueado por un cofre.
        /// </summary>
        public void UnlockAttack(GameElement element)
        {
            if (element == GameElement.Ninguno) return;
            attacksMask |= Bit(element);
        }

        public void EquipElement(int characterIndex, GameElement element)
        {
            EquipElement(characterIndex, 1, element);
        }

        public void EquipElement(int characterIndex, int slotIndex, GameElement element)
        {
            if (element == GameElement.Ninguno) return;
            GameElement[] elements = ElementsForCharacter(characterIndex);
            if (elements == null || elements.Length <= slotIndex || slotIndex < 0) return;
            elements[slotIndex] = element;
            activeElement = element;
        }

        /// <summary>
        /// Registra que el jugador ya tiene el gancho disponible.
        /// </summary>
        public void UnlockGrapple()
        {
            grappleUnlocked = true;
        }

        /// <summary>
        /// Suma una moneda al contador del jugador.
        /// </summary>
        public void CollectToken()
        {
            tokenCount++;
        }

        /// <summary>
        /// Alterna entre los elementos obtenidos y devuelve el nuevo elemento
        /// activo.
        /// </summary>
        public GameElement SwitchElement()
        {
            GameElement[] elements = CurrentElements;
            if (elements == null || elements.Length == 0) return activeElement;
            int index = Array.IndexOf(elements, activeElement);
            activeElement = elements[(index + 1 + elements.Length) % elements.Length];
            return activeElement;
        }

        /// <summary>
        /// Selecciona un personaje y equipa el primero de sus dos elementos.
        /// </summary>
        public void SetCharacter(int index)
        {
            currentCharacter = Mathf.Clamp(index, 0, CharacterCount - 1);
            GameElement[] elements = CurrentElements;
            if (elements == null || elements.Length == 0) return;
            if (Array.IndexOf(elements, activeElement) < 0)
                activeElement = elements[0];
        }

        /// <summary>
        /// Gasta monedas si hay suficientes. Devuelve true si se pudo comprar.
        /// </summary>
        public bool SpendTokens(int amount)
        {
            if (amount <= 0 || tokenCount < amount) return false;
            tokenCount -= amount;
            return true;
        }

        /// <summary>
        /// Muestra un mensaje en el HUD durante el tiempo indicado.
        /// </summary>
        public void ShowMessage(string text, float duration = 3f)
        {
            message = text;
            messageExpiry = Time.time + duration;
        }

        /// <summary>
        /// Limpia el progreso de la partida. Se ejecuta al iniciar el juego.
        /// </summary>
        public void ResetProgress()
        {
            elementsMask = 0;
            foreach (GameElement element in ElementsForCharacter(0)) elementsMask |= Bit(element);
            foreach (GameElement element in ElementsForCharacter(1)) elementsMask |= Bit(element);

            attacksMask = 0;
            tokenCount = 0;
            currentCharacter = 0;
            GameElement[] startingElements = ElementsForCharacter(0);
            activeElement = startingElements != null && startingElements.Length > 0
                ? startingElements[0]
                : GameElement.Ninguno;
            grappleUnlocked = false;
            message = string.Empty;
            messageExpiry = 0f;
        }

        /// <summary>
        /// Copia la configuración guardada en la escena sobre este modelo
        /// manteniendo la misma instancia compartida por la simulación.
        /// </summary>
        public void CopyConfigurationFrom(PlatformerModel other)
        {
            if (other == null || ReferenceEquals(other, this)) return;
            virtualCamera = other.virtualCamera;
            player = other.player;
            spawnPoint = other.spawnPoint;
            jumpModifier = other.jumpModifier;
            jumpDeceleration = other.jumpDeceleration;
            knightElements = other.knightElements != null && other.knightElements.Length > 0
                ? (GameElement[])other.knightElements.Clone()
                : new[] { GameElement.Fuego, GameElement.Rayo };
            cyberElements = other.cyberElements != null && other.cyberElements.Length > 0
                ? (GameElement[])other.cyberElements.Clone()
                : new[] { GameElement.Hielo, GameElement.Viento };
        }

        static int Bit(GameElement element)
        {
            return 1 << (int)element;
        }
    }
}
