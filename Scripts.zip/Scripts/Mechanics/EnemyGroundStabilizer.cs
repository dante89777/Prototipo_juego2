using UnityEngine;

namespace Platformer.Mechanics
{
    [RequireComponent(typeof(AnimationController), typeof(Rigidbody2D), typeof(SpriteRenderer))]
    public class EnemyGroundStabilizer : MonoBehaviour
    {
        [SerializeField] private float snapDistance = 0.6f;
        [SerializeField] private float probeDistance = 1f;

        Rigidbody2D body;
        SpriteRenderer spriteRenderer;
        Collider2D ownCollider;
        KinematicObject kinematic;

        void Awake()
        {
            body = GetComponent<Rigidbody2D>();
            spriteRenderer = GetComponent<SpriteRenderer>();
            ownCollider = GetComponent<Collider2D>();
            kinematic = GetComponent<KinematicObject>();
        }

        void LateUpdate()
        {
            if (body == null || spriteRenderer == null || spriteRenderer.sprite == null) return;

            float bottomOffset = -spriteRenderer.bounds.extents.y;
            if (ownCollider is BoxCollider2D box)
                bottomOffset = (box.offset.y - box.size.y * 0.5f) * transform.lossyScale.y;
            else if (ownCollider != null)
                bottomOffset = ownCollider.bounds.min.y - transform.position.y;

            Vector2 origin = new Vector2(body.position.x, body.position.y + bottomOffset + probeDistance);
            RaycastHit2D[] hits = Physics2D.RaycastAll(origin, Vector2.down, probeDistance * 2f);

            float groundY = float.MinValue;
            bool found = false;
            foreach (RaycastHit2D hit in hits)
            {
                if (hit.collider == null || hit.collider == ownCollider || hit.collider.isTrigger) continue;
                if (hit.collider.GetComponent<EnemyController>() != null || hit.collider.GetComponent<KinematicObject>() != null) continue;
                if (hit.normal.y < 0.5f) continue;
                if (hit.point.y > groundY)
                {
                    groundY = hit.point.y;
                    found = true;
                }
            }

            if (!found) return;
            float targetY = groundY - bottomOffset;
            if (Mathf.Abs(body.position.y - targetY) > snapDistance) return;

            body.position = new Vector2(body.position.x, targetY);
            if (kinematic != null)
            {
                kinematic.velocity = new Vector2(kinematic.velocity.x, 0f);
                kinematic.SetGrounded(true);
            }
        }
    }
}
