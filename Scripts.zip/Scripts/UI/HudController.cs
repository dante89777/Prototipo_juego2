using Platformer.Core;
using Platformer.Mechanics;
using Platformer.Model;
using TMPro;
using UnityEngine;

namespace Platformer.UI
{
    /// <summary>
    /// HUD del juego. Muestra las monedas recogidas, el elemento activo, la
    /// vida del jugador y los mensajes de recompensa.
    /// </summary>
    public class HudController : MonoBehaviour
    {
        [Tooltip("Texto con el número de monedas. Se busca por nombre dentro del HUD.")]
        [SerializeField] private string tokensLabelName = "Tokens";
        [Tooltip("Texto con el elemento activo.")]
        [SerializeField] private string elementLabelName = "Elemento";
        [Tooltip("Texto con el personaje activo.")]
        [SerializeField] private string characterLabelName = "Personaje";
        [Tooltip("Texto con los dos elementos del personaje.")]
        [SerializeField] private string elementsLabelName = "Elementos";
        [Tooltip("Texto con la vida del jugador.")]
        [SerializeField] private string lifeLabelName = "Vida";
        [Tooltip("Texto para los mensajes de recompensa.")]
        [SerializeField] private string messageLabelName = "Mensaje";

        TMP_Text tokensLabel;
        TMP_Text elementLabel;
        TMP_Text characterLabel;
        TMP_Text elementsLabel;
        TMP_Text lifeLabel;
        TMP_Text messageLabel;

        readonly PlatformerModel model = Simulation.GetModel<PlatformerModel>();

        void Awake()
        {
            tokensLabel = FindLabel(tokensLabelName);
            elementLabel = FindLabel(elementLabelName);
            characterLabel = FindLabel(characterLabelName);
            elementsLabel = FindLabel(elementsLabelName);
            lifeLabel = FindLabel(lifeLabelName);
            messageLabel = FindLabel(messageLabelName);
        }

        void Update()
        {
            if (tokensLabel != null)
                tokensLabel.text = $"MONEDAS: {model.TokenCount}";

            if (elementLabel != null)
                elementLabel.text = $"ELEMENTO: {NameOf(model.ActiveElement)}";

            if (characterLabel != null)
                characterLabel.text = $"PERSONAJE [{model.CurrentCharacterIndex + 1}] {model.CurrentCharacterName}";

            if (elementsLabel != null)
                elementsLabel.text = $"ELEMENTOS: {FormatElements(model.CurrentElements)}";

            if (lifeLabel != null)
            {
                Health health = model.player != null ? model.player.Health : null;
                if (health != null)
                    lifeLabel.text = $"VIDA: {health.CurrentHP}/{health.MaxHP}";
            }

            if (messageLabel != null)
                messageLabel.text = model.Message;
        }

        TMP_Text FindLabel(string objectName)
        {
            Transform found = transform.Find(objectName);
            return found != null ? found.GetComponent<TMP_Text>() : null;
        }

        static string FormatElements(GameElement[] elements)
        {
            if (elements == null || elements.Length == 0) return "-";
            var parts = new string[elements.Length];
            for (int i = 0; i < elements.Length; i++)
                parts[i] = NameOf(elements[i]);
            return string.Join(" / ", parts);
        }

        static string NameOf(GameElement value)
        {
            switch (value)
            {
                case GameElement.Fuego: return "FUEGO";
                case GameElement.Rayo: return "RAYO";
                case GameElement.Hielo: return "HIELO";
                case GameElement.Tierra: return "TIERRA";
                case GameElement.Planta: return "PLANTA";
                case GameElement.Viento: return "VIENTO";
                case GameElement.Agua: return "AGUA";
                default: return "NINGUNO";
            }
        }
    }
}
